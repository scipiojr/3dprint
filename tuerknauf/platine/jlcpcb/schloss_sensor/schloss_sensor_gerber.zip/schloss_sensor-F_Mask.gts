%TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*%
%TF.CreationDate,2026-10-14T18:26:51+02:00*%
%TF.ProjectId,schloss_sensor,7363686c-6f73-4735-9f73-656e736f722e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-10-14 18:26:51*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10RoundRect,0.044000X-0.063640X-0.156978X0.156978X0.063640X0.063640X0.156978X-0.156978X-0.063640X0*%
%ADD11RotRect,0.350000X0.700000X45.000000*%
%ADD12RoundRect,0.044000X0.156978X-0.063640X-0.063640X0.156978X-0.156978X0.063640X0.063640X-0.156978X0*%
%ADD13RotRect,0.350000X0.700000X135.000000*%
%ADD14RoundRect,0.140000X0.037968X-0.216930X0.220185X-0.004334X-0.037968X0.216930X-0.220185X0.004334X0*%
%ADD15RoundRect,0.140000X-0.220185X-0.004334X-0.037968X-0.216930X0.220185X0.004334X0.037968X0.216930X0*%
%ADD16R,0.800000X0.800000*%
%ADD17C,0.800000*%
G04 APERTURE END LIST*
D10*
%TO.C,U2*%
X13449171Y-14198704D03*
X13802724Y-14552257D03*
X14552257Y-13802724D03*
X14198704Y-13449171D03*
D11*
X14000714Y-14000714D03*
%TD*%
D12*
%TO.C,U1*%
X-13802724Y-14552257D03*
X-13449171Y-14198704D03*
X-14198704Y-13449171D03*
X-14552257Y-13802724D03*
D13*
X-14000714Y-14000714D03*
%TD*%
D14*
%TO.C,C1*%
X-13197701Y-15398021D03*
X-12572957Y-14669121D03*
%TD*%
D15*
%TO.C,C2*%
X12572957Y-14669121D03*
X13197701Y-15398021D03*
%TD*%
D16*
%TO.C,J1*%
X-12227922Y-13227922D03*
D17*
X-13227922Y-12227922D03*
X-13227922Y-13227922D03*
X-12227922Y-12227922D03*
%TD*%
M02*
